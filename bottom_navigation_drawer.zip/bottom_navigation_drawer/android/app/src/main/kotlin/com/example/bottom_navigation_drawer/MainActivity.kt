package com.example.bottom_navigation_drawer

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
