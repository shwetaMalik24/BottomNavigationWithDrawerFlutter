import 'package:flutter/material.dart';
class DrawerTopHeader extends StatelessWidget{

  @override
  Widget build(BuildContext context) {
    return Container(
      height:200,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.green,
      ),
      child: Container(
        alignment: Alignment.center,
        //margin: EdgeInsets.only(top: widget.appBarHeight * .3),
        padding: const EdgeInsets.only(
          left: 40,
          right: 40,
        ),
        child: Text("Shweta Malik",
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            textAlign: TextAlign.center,
            style: Theme.of(context)
                .textTheme
                .headline1
                .copyWith(color: Colors.white, fontSize: 16)),
      ),
    );
  }
}
