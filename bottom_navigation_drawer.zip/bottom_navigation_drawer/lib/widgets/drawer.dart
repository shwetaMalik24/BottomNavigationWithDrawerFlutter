import 'package:bottom_navigation_drawer/utils/page_type.dart';
import 'package:bottom_navigation_drawer/utils/strings.dart';
import 'package:bottom_navigation_drawer/utils/theme.dart';
import 'package:bottom_navigation_drawer/widgets/drawer_header.dart';
import 'package:flutter/material.dart';

class MyDrawer extends StatelessWidget {
  final Function(PageType) onItemSelected;
  MyDrawer({Key key, this.onItemSelected}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final height = MediaQuery.of(context).size.height;
    return SafeArea(
      left: false,
      top: true,
      right: false,
      bottom: false,
      child: Drawer(
        child: Stack(
          children: [
            ListView(
              padding: EdgeInsets.all(0),
              children: [
                _createDrawerHeader(height),
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.only(
                    left: 14.0,
                  ),
                  title: Text(
                    Strings.HOME,
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    onItemSelected(PageType.HOME);
                  },
                ),
                const Divider(
                  color: ThemeColor.dividerColor,
                  height: 3,
                ),
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.only(
                    left: 14.0,
                  ),
                  title: Text(
                    Strings.PROFILE,
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    onItemSelected(PageType.PROFILE);
                  },
                ),
                const Divider(
                  color: ThemeColor.dividerColor,
                  height: 3,
                ),
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.only(
                    left: 14.0,
                  ),
                  title: Text(
                    Strings.NOTIFICATION,
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    onItemSelected(PageType.NOTIFICATION);
                  },
                ),
                const Divider(
                  color: ThemeColor.dividerColor,
                  height: 3,
                ),
                ListTile(
                  dense: true,
                  contentPadding: EdgeInsets.only(
                    left: 14.0,
                  ),
                  title: Text(
                    Strings.SETTINGS,
                    style: Theme.of(context).textTheme.headline6,
                  ),
                  onTap: () {
                    Navigator.pop(context);
                    onItemSelected(PageType.SETTINGS);
                  },
                ),
                const Divider(
                  color: ThemeColor.dividerColor,
                  height: 3,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  _createDrawerHeader(double height) {
    return Container(
      height: height * 0.2,
      child: DrawerHeader(
        margin: EdgeInsets.zero,
        padding: EdgeInsets.zero,
        child: DrawerTopHeader(),
      ),
    );
  }
}
