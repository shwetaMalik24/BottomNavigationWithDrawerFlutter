import 'package:bottom_navigation_drawer/pages/landing_page.dart';
import 'package:bottom_navigation_drawer/utils/theme.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        accentColor: ThemeColor.accentColor,
        primaryColor: ThemeColor.primaryColor,
        primaryColorDark: ThemeColor.primaryDarkColor,
        backgroundColor: Colors.white,
        dividerColor: ThemeColor.dividerColorDefault,
        dialogBackgroundColor: Colors.white,
        scaffoldBackgroundColor: Colors.white,
        canvasColor: Colors.white,
        brightness: Brightness.light,
        textTheme: textTheme,
        indicatorColor: ThemeColor.primaryColor,
      ),
      debugShowCheckedModeBanner: false,
      home: LandingPage(),
    );
  }
}
