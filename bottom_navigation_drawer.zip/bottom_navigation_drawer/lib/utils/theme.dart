import 'package:flutter/material.dart';

const String SOURCE_SANS_PRO = "SourceSansPro";

class ThemeColor {
  /// Colors.............
  static const Color accentColor = Color(0xffae377b);
  static const Color accentColor1 = Color(0xffed6c60);
  static const Color primaryColor = Color(0xff141d39);
  static const Color primaryDarkColor = Color(0xff0A1127);
  static const Color dividerColorDefault = Colors.black54;
  static const Color backgroundGrey = const Color(0xFFD8D8D8);
  static const Color backgroundColor = const Color(0xFFE9E7E3);
  static const Color blueText = const Color(0xFF004080);
  static const Color black1c = Color(0xFF1c1c1e);
  static const Color loginPurple = Color(0xFF0A081B);
  static const Color textBackground = Color(0xFFECEEED);
  static const Color textColor = Color(0xFF070606);
  static const Color undoButtonColor = Color(0xFF0A081B);
  static const Color greencolor = Color(0xFF237926);
  static const Color redColor = Color(0xFFC50A0A);
  static const Color dialogYellow = Color(0xFFFF8008);
  static const Color dialogRed = Color(0xFFFF0801);
  static const Color containerBackground = Color(0xFFE9E7E3);
  static const Color notStartedBackground = Color(0xFF4E69AF);
  static const Color dividerColor = Color(0xFFDCDCDC);


}

// NAME         SIZE  WEIGHT  SPACING
// headline1    96.0  light   -1.5
// headline2    60.0  light   -0.5
// headline3    48.0  regular  0.0
// headline4    34.0  regular  0.25
// headline5    24.0  regular  0.0
// headline6    20.0  medium   0.15
// subtitle1    16.0  regular  0.15
// subtitle2    14.0  medium   0.1
// bodyText1    16.0  regular  0.5
// bodyText2    14.0  regular  0.25
// button       14.0  medium   1.25
// caption      12.0  regular  0.4
// overline     10.0  regular  1.5
final TextTheme textTheme = TextTheme(
  headline6: TextStyle(
      debugLabel: 'headline6',
      inherit: true,
      color: Colors.black,
      decoration: TextDecoration.none,
      fontFamily: SOURCE_SANS_PRO),
  headline5: TextStyle(
      debugLabel: 'headline5',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  headline4: TextStyle(
      debugLabel: 'headline4',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  headline3: TextStyle(
      debugLabel: 'headline3',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  headline2: TextStyle(
      debugLabel: 'headline2',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  headline1: TextStyle(
      debugLabel: 'headline1',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  subtitle1: TextStyle(
      debugLabel: 'subtitle1',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  subtitle2: TextStyle(
      debugLabel: 'subtitle2',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  bodyText1: TextStyle(
      debugLabel: 'bodyText1',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  bodyText2: TextStyle(
      debugLabel: 'bodyText1',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  caption: TextStyle(
      debugLabel: 'caption',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  button: TextStyle(
      debugLabel: 'button',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
  overline: TextStyle(
      debugLabel: 'overline',
      inherit: true,
      color: Colors.black,
      fontFamily: SOURCE_SANS_PRO),
);

///100% — FF
///95% — F2
///90% — E6
///85% — D9
///80% — CC
///75% — BF
///70% — B3
///65% — A6
///60% — 99
///55% — 8C
///50% — 80
///45% — 73
///40% — 66
///35% — 59
///30% — 4D
///25% — 40
///20% — 33
///15% — 26
///10% — 1A
///5% — 0D
///0% — 00
