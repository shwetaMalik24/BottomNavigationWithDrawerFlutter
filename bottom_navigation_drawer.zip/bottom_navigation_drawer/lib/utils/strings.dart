class Strings {
  static const HOME = "Home";
  static const NOTIFICATION = "Notifications";
  static const PROFILE = "Profile";
  static const SETTINGS = "Settings";
}