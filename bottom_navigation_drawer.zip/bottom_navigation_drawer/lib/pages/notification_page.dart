import 'package:bottom_navigation_drawer/utils/strings.dart';
import 'package:bottom_navigation_drawer/utils/theme.dart';
import 'package:flutter/material.dart';

class NotificationPage extends StatelessWidget{
  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Scaffold(
      body: Container(
        color: ThemeColor.backgroundColor,
        child: Center(
          child: Text(Strings.NOTIFICATION),
        ),
      ),
    );
  }
}