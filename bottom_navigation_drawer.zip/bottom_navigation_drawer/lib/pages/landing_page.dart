import 'package:bottom_navigation_drawer/pages/profile_page.dart';
import 'package:bottom_navigation_drawer/pages/settings_page.dart';
import 'package:bottom_navigation_drawer/utils/page_type.dart';
import 'package:bottom_navigation_drawer/utils/strings.dart';
import 'package:bottom_navigation_drawer/utils/theme.dart';
import 'package:bottom_navigation_drawer/widgets/drawer.dart';
import 'package:flutter/material.dart';
import 'home_page.dart';
import 'notification_page.dart';

class LandingPage extends StatefulWidget {
  @override
  _LandingPageState createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {

  int _selectedIndex = 0;
  List<Widget> _widgetOptions;
  Widget _homePage;
  Widget _notificationPage;
  Widget _profilePage;
  Widget _settingsPage;

  @override
  void initState() {
    super.initState();
    _homePage = HomePage();
    _notificationPage = NotificationPage();
    _profilePage = ProfilePage();
    _settingsPage = SettingsPage();

    _widgetOptions = [
      _homePage,
      _profilePage,
      _notificationPage,
      _settingsPage,
    ];
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      top: true,
      left: false,
      bottom: true,
      right: false,
      minimum: const EdgeInsets.all(0.0),
      child: Scaffold(
        drawer: MyDrawer(
          onItemSelected: _onDrawerItemSelected,
        ),
        extendBodyBehindAppBar: true,
        resizeToAvoidBottomInset: false,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          iconTheme: IconThemeData(color: Colors.white),
          elevation: 0.0,
          brightness: Brightness.dark,
        ),
        body: _widgetOptions[_selectedIndex],
        bottomNavigationBar: Container(
          color: ThemeColor.backgroundGrey,
          child: BottomNavigationBar(
            elevation: 4,
            showSelectedLabels: false,
            showUnselectedLabels: false,
            iconSize: 24.0,
            selectedFontSize: 0,
            unselectedFontSize: 0,
            type: BottomNavigationBarType.fixed,
            items: <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.home_outlined,
                  size: 22.0,
                ),
                label: Strings.HOME,
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.account_circle_rounded,
                  size: 22.0,
                ),
                label: Strings.PROFILE,
              ),
              BottomNavigationBarItem(
                icon: new Stack(
                  clipBehavior: Clip.antiAliasWithSaveLayer,
                  children: <Widget>[
                    Icon(
                      Icons.notifications_none,
                      size: 22.0,
                    ),
                    // ),
                    new Positioned(
                      right: 0,
                     // bottom: 10,
                      child: new Container(
                        padding: EdgeInsets.all(2),
                        decoration: new BoxDecoration(
                          color: Colors.red,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        constraints: BoxConstraints(
                          minWidth: 15,
                          minHeight: 15,
                        ),
                        child: new Text(
                          '1',
                          style: new TextStyle(
                            color: Colors.white,
                            fontSize: 8,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  ],
                ),
                label: Strings.PROFILE,
              ),
              BottomNavigationBarItem(
                icon: Icon(
                  Icons.settings,
                  size: 22.0,
                ),
                label: Strings.SETTINGS,
              ),
            ],
            currentIndex: _selectedIndex,
            selectedItemColor: Colors.blueAccent,
            unselectedItemColor: Colors.black87,
            onTap: (int index) {
              setState(() {
                _selectedIndex = index;
              });
            },
          ),
        ),
      ),
    );
  }

  _onDrawerItemSelected(PageType pageType) {
    switch (pageType) {
      case PageType.HOME:
          setState(() {
            _selectedIndex = 0;
          });
        break;
      case PageType.PROFILE:
          setState(() {
            _selectedIndex = 1;
          });
        break;
      case PageType.NOTIFICATION:
          setState(() {
            _selectedIndex = 2;
          });
        break;
      case PageType.SETTINGS:
          setState(() {
            _selectedIndex = 3;
          });
        break;
    }
  }
}
